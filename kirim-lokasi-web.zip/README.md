# Web Kirim Lokasi

Website statis sederhana untuk mendapatkan lokasi perangkat setelah pengguna memberikan izin.

## Deploy gratis dengan GitHub Pages
1. Buat repository baru di GitHub.
2. Upload `index.html`.
3. Buka Settings → Pages.
4. Pada Source pilih `Deploy from a branch`.
5. Pilih branch `main` dan folder `/root`.
6. Simpan. GitHub akan memberikan URL website.

Catatan:
- Website membutuhkan HTTPS agar Geolocation API bekerja pada deployment publik.
- Lokasi tidak dikirim diam-diam. Browser akan meminta izin pengguna.
- Setelah lokasi didapatkan, perangkat akan membuka menu Share jika didukung.
